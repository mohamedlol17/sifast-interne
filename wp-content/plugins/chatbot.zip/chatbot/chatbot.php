<?php
// Add this to your theme's functions.php file or a custom plugin

function simple_chatbot_shortcode() {
    // Start session to store chat history
    session_start();
    if (!isset($_SESSION['chat_history'])) {
        $_SESSION['chat_history'] = [];
    }

    $user_input = '';
    $bot_response = '';

    // Check if the form has been submitted
    if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['user_input'])) {
        $user_input = sanitize_text_field($_POST['user_input']);

        // Simple responses based on user input
        switch (strtolower($user_input)) {
            case 'hello':
                $bot_response = 'Hello! How can I help you today?';
                break;
            case 'how are you?':
                $bot_response = 'I\'m doing well, thank you! And you?';
                break;
            case 'goodbye':
                $bot_response = 'Goodbye! Have a great day!';
                break;
            default:
                $bot_response = 'Sorry, I did not understand that. Can you please repeat?';
        }

        // Save to session chat history
        $_SESSION['chat_history'][] = "User: " . $user_input;
        $_SESSION['chat_history'][] = "Bot: " . $bot_response;
    }

    // HTML Output for the chatbot
    $output = '<div id="simple-chatbot"><h1>Chat with me!</h1>';

    if (!empty($_SESSION['chat_history'])) {
        $output .= '<div>';
        foreach ($_SESSION['chat_history'] as $message) {
            $output .= '<p>' . esc_html($message) . '</p>';
        }
        $output .= '</div>';
    }

    $output .= '<form method="post">';
    $output .= '<input type="text" name="user_input" placeholder="Say something..." autofocus>';
    $output .= '<button type="submit">Send</button>';
    $output .= '</form></div>';

    return $output;
}

// Register the shortcode in WordPress
add_shortcode('simple_chatbot', 'simple_chatbot_shortcode');
?>

